/*
 * DAC.h
 *
 *  Created on: Nov 26, 2017
 *      Author: Jes�s Arnoldo Zerecero N��ez
 */

#ifndef DAC_H_
#define DAC_H_

void vfnDACGPIOInit(void);

void vfnDACInitConfig(void);

void vfnDACWrite(unsigned short wValue);

void vfnSignalOnOff(void);

#endif /* DAC_H_ */
